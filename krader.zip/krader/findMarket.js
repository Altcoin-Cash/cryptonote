const api = require("./api")

start = async () => {
    console.info("Get all markets")
    const markets = await api.allMarketsTicker()

    console.info("Health check the markets")
    let healthyMarkets = {}
    for (const market of Object.keys(markets)) {
        console.log(market)
        try {
            const book = await api.orderBook(market)
            if (book && !book.error) {
                healthyMarkets[market] = markets[market]
            }
        } catch(e) {/* do nothing */}
    }
    console.info({
        healthy: Object.keys(healthyMarkets).length,
        dead: Object.keys(markets).length - Object.keys(healthyMarkets).length
    })
    let results = []
    Object.entries(healthyMarkets).forEach(([market, details]) => {
        const d = details.ticker
        const volume = d.volbtc
        const spread = (d.sell / d.buy).toFixed(2)
        const change = (d.high / d.low).toFixed(2)
        const score = volume * spread
        results.push({ market, volume, spread, change, score })
    })
    results.sort((a, b) => b.score - a.score)
    console.log("TOP 10")
    console.info(results.slice(0, 10))
}

start()