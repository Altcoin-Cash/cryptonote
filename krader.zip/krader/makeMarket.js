const api = require("./api")
var theMarket = "olmpbtc";
var increase = 0.000000001;
var volume = 10;

let activeBuyOrder = {}
let activeSellOrder = {}
let lastBuyIncrease = 0
let lastSellIncrease = 0

async function makeMarket() {
    console.info("")

    // Get market details
    const orderBook = await api.orderBook(theMarket)
    if (!orderBook) {
        console.info("orderBook is non-existent")
        return
    }
    const myAsk = orderBook.asks[0].id === activeSellOrder.id
    const myBid = orderBook.bids[0].id === activeBuyOrder.id
    const topAsk = parseFloat(orderBook.asks[myAsk ? 1 : 0].price)
    const topBid = parseFloat(orderBook.bids[myBid ? 1 : 0].price)
    const spread = ((topAsk - increase) - (topBid + increase)).toFixed(9)
    console.info({topAsk, topBid, spread})
    if (spread < 0.00000003) {
        console.info("Not worth the spread")
        return
    }

    // Calculate prices to use
    const sellPrice = (topAsk - increase).toFixed(9)
    const buyPrice = (topBid + increase).toFixed(9)
    if (activeSellOrder && sellPrice === activeSellOrder.price && activeBuyOrder &&  buyPrice === activeBuyOrder.price) {
        console.info("Prices have not changed.")
        return
    }

    // Detect overbid spiral
    const nowSellIncrease = (activeSellOrder.price - topAsk).toFixed(9)
    const nowBuyIncrease = (topBid - activeBuyOrder.price).toFixed(9)
    // Someone is offering better price
    if (nowSellIncrease > 0 || nowBuyIncrease > 0) {
        // Gap is same as last time overbid happened
        if (nowSellIncrease === lastSellIncrease || nowBuyIncrease === lastBuyIncrease) {
            console.info("Overbid repeats, stay put.", {
                nowSellIncrease,
                lastSellIncrease,
                nowBuyIncrease,
                lastBuyIncrease
            })
            return    
        }

        lastSellIncrease = nowSellIncrease
        lastBuyIncrease = nowBuyIncrease
    }

    // Create orders
    await api.clearAllOrders()
    activeBuyOrder = await api.createOrder(theMarket, "buy", volume, buyPrice)
    activeSellOrder = await api.createOrder(theMarket, "sell", volume, sellPrice)
    console.info({
        "buy": ` ${activeBuyOrder.id} | ${activeBuyOrder.state} | ${buyPrice}`,
        "sell": `${activeSellOrder.id} | ${activeSellOrder.state} | ${sellPrice}`,
    })

}

makeMarket()
setInterval(makeMarket, 30 * 1000);
