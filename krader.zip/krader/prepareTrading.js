const moveToBase = require('./lib/moveToBase')
const moveToCurrency = require('./lib/moveToCurrency')

start = async () => {
    await moveToBase()
    await moveToCurrency()
}
start()