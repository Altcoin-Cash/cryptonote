var graviex = require("./graviex")

graviex.accessKey = "Mw6tZKnhAu4I1BTfi27KGQVuhE67luoDbeZeB4Nn"
graviex.secretKey = "HgTCgVLLhTmc9lLSU9kydH3vYcN1IyR7i41y5SG3"

module.exports = {
    allMarketsTicker: promisify('allMarketsTicker'),
    clearAllOrders: promisify('clearAllOrders'),
    orderBook: promisify('orderBook'),
    createOrder: promisify('createOrder'),
    allDeposits: promisify('allDeposits'),
    account: promisify('account'),
}

function promisify(functionName, ...args) {
    return function(...args) {
        return new Promise((resolve, reject) => {
            graviex[functionName](...args, (result) => {
                if (result.error) {
                    reject(result.error)
                } else {
                    resolve(result)
                }
            })
        }).catch(e => console.info(e))
    }
}