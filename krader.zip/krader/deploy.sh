docker stop $(docker ps -a -q)                                                                
docker rm $(docker ps -a -q)
docker build -t foo .
docker run -d --restart always --name olmp foo
docker logs -f olmp
