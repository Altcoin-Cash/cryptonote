module.exports = {
    baseCurrency: 'btc',
    activeCurrency: 'olmp'
}